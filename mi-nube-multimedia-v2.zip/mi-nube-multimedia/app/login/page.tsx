'use client'

import { FormEvent, useState } from 'react'
import { Cloud, LockKeyhole, Mail, ShieldCheck } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event: FormEvent) {
    event.preventDefault()
    setLoading(true)
    setMessage('')
    const supabase = createClient()
    const result = mode === 'login'
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password })

    if (result.error) setMessage(result.error.message)
    else if (mode === 'signup') setMessage('Cuenta creada. Revisa tu correo si la confirmación está activada.')
    else window.location.href = '/dashboard'
    setLoading(false)
  }

  return (
    <main className="auth-page">
      <section className="auth-card">
        <div className="auth-brand"><span className="brand-mark"><Cloud size={22}/></span><span>Mi Nube <b>Multimedia</b></span></div>
        <div className="auth-hero">
          <div className="eyebrow">TU ESPACIO DIGITAL</div>
          <h1>{mode === 'login' ? 'Todo tu contenido, en un solo lugar.' : 'Crea tu nube privada.'}</h1>
          <p>Guarda fotos, videos, audio y documentos con una organización sencilla y acceso privado.</p>
        </div>
        <form onSubmit={submit} className="auth-form">
          <label>Correo electrónico</label>
          <div className="input-wrap"><Mail size={18}/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="tu@correo.com"/></div>
          <label>Contraseña</label>
          <div className="input-wrap"><LockKeyhole size={18}/><input type="password" minLength={6} value={password} onChange={e=>setPassword(e.target.value)} required placeholder="Mínimo 6 caracteres"/></div>
          <button className="primary-btn" disabled={loading}>{loading ? 'Procesando…' : mode === 'login' ? 'Entrar a mi nube' : 'Crear mi cuenta'}</button>
          {message && <div className="auth-message">{message}</div>}
        </form>
        <button className="switch-btn" onClick={()=>{setMessage('');setMode(mode === 'login' ? 'signup' : 'login')}}>
          {mode === 'login' ? '¿Primera vez? Crear cuenta' : 'Ya tengo cuenta. Iniciar sesión'}
        </button>
        <div className="security-line"><ShieldCheck size={16}/> Archivos privados con control de acceso de Supabase</div>
      </section>
    </main>
  )
}
